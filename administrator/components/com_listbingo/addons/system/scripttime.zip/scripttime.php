<?php

defined('JPATH_BASE') or die();

gbimport( 'gobingoo.event' );
gbimport("gobingoo.helper");


class evtSystemScripttime extends GEvent
{

	function onSystemStart()
	{

		
		$app=JFactory::getApplication();
		$app->set('starttime',microtime());
	}
	
	function onAfterDispatch()
	{
		$app=JFactory::getApplication();
		$currenttime=microtime();
		$starttime=$app->get('starttime');
		$timediff=(float)$currenttime-(float)$starttime;
		echo "Listbingo Execution Time ".$timediff . " sec";
	}

}
?>